<?php
/**
 * Plugin Name: Carrothost Server-Side Tracker
 * Plugin URI: https://apptimatic.com/wordpress-server-side-tracker
 * Description: High-speed, Node-Free Server-Side Tracking for Google Tag Manager & Facebook Conversions API (CAPI) with WooCommerce support.
 * Version: 1.3.5
 * Author: Apptimatic
 * Author URI: https://apptimatic.com
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

// ১. প্লাগইন অ্যাকশন লিংক (Settings | Deactivate)
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'chnf_add_action_links');
function chnf_add_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=carrothost-sst')) . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// ২. Author ও Plugin Site লিংকে target="_blank"
add_filter('plugin_row_meta', 'chnf_modify_plugin_row_meta', 10, 2);
function chnf_modify_plugin_row_meta($plugin_meta, $plugin_file) {
    if ($plugin_file === plugin_basename(__FILE__)) {
        foreach ($plugin_meta as $key => $meta_html) {
            if (strpos($meta_html, 'href=') !== false && strpos($meta_html, 'target=') === false) {
                $plugin_meta[$key] = str_replace('<a ', '<a target="_blank" rel="noopener noreferrer" ', $meta_html);
            }
        }
    }
    return $plugin_meta;
}

// ৩. অ্যাডমিন মেনু তৈরি
add_action('admin_menu', 'chnf_add_admin_menu');
function chnf_add_admin_menu() {
    add_menu_page(
        'Carrothost SST',
        'Carrothost SST',
        'manage_options',
        'carrothost-sst',
        'chnf_render_admin_page',
        'dashicons-chart-line',
        99
    );
}

// ৪. সেটিংস ভ্যারিয়েবল রেজিস্টার
add_action('admin_init', 'chnf_register_settings');
function chnf_register_settings() {
    register_setting('chnf_options_group', 'chnf_gtm_id');
    register_setting('chnf_options_group', 'chnf_fb_pixel_id');
    register_setting('chnf_options_group', 'chnf_fb_access_token');
    register_setting('chnf_options_group', 'chnf_fb_test_code');
}

// ৫. অ্যাডমিন UI (স্ক্রলবার ফ্রি রেসপন্সিভ ডিজাইন)
function chnf_render_admin_page() {
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'status';
    
    // লগ ক্লিয়ার হ্যান্ডলিং
    if (isset($_POST['chnf_clear_logs']) && check_admin_referer('chnf_clear_logs_action', 'chnf_clear_logs_nonce')) {
        delete_option('chnf_event_logs');
        echo '<div class="notice notice-success is-dismissible"><p>Activity logs cleared successfully.</p></div>';
    }

    // টেস্ট পিং হ্যান্ডলিং
    if (isset($_POST['chnf_test_connections']) && check_admin_referer('chnf_test_conn_action', 'chnf_test_conn_nonce')) {
        chnf_run_diagnostics_ping();
        echo '<div class="notice notice-success is-dismissible"><p>Diagnostic test executed! Check the logs and status below.</p></div>';
    }
    ?>
    <style>
        .chnf-container {
            max-width: 100%;
            overflow-x: hidden;
            box-sizing: border-box;
            padding-right: 15px;
        }
        .chnf-table {
            width: 100%;
            table-layout: fixed;
            word-wrap: break-word;
            box-sizing: border-box;
        }
        .chnf-table td, .chnf-table th {
            overflow: hidden;
            text-overflow: ellipsis;
            vertical-align: middle;
        }
        .chnf-details-cell {
            word-break: break-all;
            white-space: normal;
        }
        .chnf-header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 12px;
        }
    </style>

    <div class="wrap chnf-container">
        <h1>🚀 Carrothost Server-Side Tracker</h1>
        
        <h2 class="nav-tab-wrapper" style="margin-bottom: 20px;">
            <a href="?page=carrothost-sst&tab=status" class="nav-tab <?php echo $active_tab === 'status' ? 'nav-tab-active' : ''; ?>">📊 Connection Health & Logs</a>
            <a href="?page=carrothost-sst&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">⚙️ Configuration</a>
        </h2>

        <?php if ($active_tab === 'status'): 
            $gtm_id = get_option('chnf_gtm_id');
            $fb_pixel_id = trim(get_option('chnf_fb_pixel_id'));
            $fb_token = trim(get_option('chnf_fb_access_token'));
            
            // GTM Nginx হেলথ চেক
            $test_id = !empty($gtm_id) ? $gtm_id : 'GTM-KK6466MJ';
            $full_gtm_proxy_url = home_url('/metrics/gtm.js?id=' . $test_id);
            $gtm_res = wp_remote_get($full_gtm_proxy_url, ['timeout' => 4]);
            $is_gtm_ok = (!is_wp_error($gtm_res) && wp_remote_retrieve_response_code($gtm_res) === 200);

            // CAPI স্ট্যাটাস চেক
            $last_fb_status = get_option('chnf_fb_last_status', 'pending');
            $logs = get_option('chnf_event_logs', []);
        ?>
            <div class="chnf-header-flex">
                <h3 style="margin: 0;">Live Diagnostics & Connection Health</h3>
                <form method="post" action="">
                    <?php wp_nonce_field('chnf_test_conn_action', 'chnf_test_conn_nonce'); ?>
                    <input type="submit" name="chnf_test_connections" class="button button-primary" value="⚡ Run Test Ping Now" />
                </form>
            </div>

            <table class="widefat fixed striped chnf-table" style="margin-bottom: 25px;">
                <tbody>
                    <tr>
                        <td style="width: 220px;"><strong>Google Nginx Proxy</strong></td>
                        <td class="chnf-details-cell">
                            <?php if ($is_gtm_ok): ?>
                                <span style="color: #46b450; font-weight: bold;">● Connected & Serving First-Party Data (200 OK)</span>
                                <br><small><a href="<?php echo esc_url($full_gtm_proxy_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($full_gtm_proxy_url); ?> ↗</a></small>
                            <?php else: ?>
                                <span style="color: #dc3232; font-weight: bold;">● Endpoint Not Responding</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Facebook CAPI (Server-Side)</strong></td>
                        <td>
                            <?php if (empty($fb_pixel_id)): ?>
                                <span style="color: #999;">● Pixel ID Not Configured</span>
                            <?php elseif (empty($fb_token)): ?>
                                <span style="color: #dba617; font-weight: bold;">● Browser Pixel Active (No Access Token for CAPI)</span>
                            <?php elseif ($last_fb_status === 'success'): ?>
                                <span style="color: #46b450; font-weight: bold;">● Server-Side API Authenticated & Active (200 OK)</span>
                            <?php else: ?>
                                <span style="color: #2271b1; font-weight: bold;">● Ready (Click "Run Test Ping Now" above to verify token)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>WooCommerce Tracking</strong></td>
                        <td>
                            <?php echo class_exists('WooCommerce') ? '<span style="color: #46b450; font-weight: bold;">● WooCommerce Detected & Hooked</span>' : '<span style="color: #999;">Not Installed (Optional)</span>'; ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="chnf-header-flex">
                <h3 style="margin: 0;">Recent Activity & Dispatch Logs (Last 10 Events)</h3>
                <form method="post" action="">
                    <?php wp_nonce_field('chnf_clear_logs_action', 'chnf_clear_logs_nonce'); ?>
                    <input type="submit" name="chnf_clear_logs" class="button button-secondary" value="Clear Logs" />
                </form>
            </div>

            <table class="widefat fixed striped chnf-table">
                <thead>
                    <tr>
                        <th style="width: 140px;">Time</th>
                        <th style="width: 110px;">Event</th>
                        <th style="width: 140px;">Target</th>
                        <th style="width: 150px;">Status</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): ?>
                        <?php foreach (array_reverse($logs) as $log): ?>
                            <tr>
                                <td><?php echo esc_html($log['time']); ?></td>
                                <td><strong><?php echo esc_html($log['event']); ?></strong></td>
                                <td><?php echo esc_html($log['target']); ?></td>
                                <td>
                                    <?php if (strpos($log['status'], '200') !== false || strpos($log['status'], 'Success') !== false): ?>
                                        <span style="color: #46b450; font-weight: bold;">● <?php echo esc_html($log['status']); ?></span>
                                    <?php else: ?>
                                        <span style="color: #dc3232; font-weight: bold;">● <?php echo esc_html($log['status']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="chnf-details-cell"><code><?php echo esc_html($log['details']); ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">No tracking activity logged yet. Click "Run Test Ping Now" above to verify immediately.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        <?php else: ?>
            <p>Configure your tracking IDs below. Data routes directly through the high-speed Nginx proxy (<code>/metrics/</code>).</p>
            <form method="post" action="options.php">
                <?php settings_fields('chnf_options_group'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Google Tag Manager ID</th>
                        <td>
                            <input type="text" name="chnf_gtm_id" value="<?php echo esc_attr(get_option('chnf_gtm_id')); ?>" placeholder="GTM-XXXXXXX" class="regular-text" />
                            <p class="description">Web GTM Container ID.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Facebook Pixel ID</th>
                        <td>
                            <input type="text" name="chnf_fb_pixel_id" value="<?php echo esc_attr(get_option('chnf_fb_pixel_id')); ?>" placeholder="123456789012345" class="regular-text" />
                            <p class="description">Required for Meta Browser Pixel & CAPI.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Facebook CAPI Access Token</th>
                        <td>
                            <textarea name="chnf_fb_access_token" rows="4" class="large-text" placeholder="EAA..."><?php echo esc_attr(get_option('chnf_fb_access_token')); ?></textarea>
                            <p class="description">Meta Events Manager > Settings > Conversions API (Leave blank if using Browser Pixel only).</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Facebook Test Event Code (Optional)</th>
                        <td>
                            <input type="text" name="chnf_fb_test_code" value="<?php echo esc_attr(get_option('chnf_fb_test_code')); ?>" placeholder="TEST12345" class="regular-text" />
                            <p class="description">Only for testing. Keep blank for live production tracking.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save & Enable Tracking'); ?>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

// ৬. Nginx Proxy দিয়ে GTM ও Browser Pixel ইনজেকশন
add_action('wp_head', 'chnf_inject_tracking_scripts', 1);
function chnf_inject_tracking_scripts() {
    $gtm_id = get_option('chnf_gtm_id');
    $fb_pixel_id = get_option('chnf_fb_pixel_id');

    // GTM Script
    if (!empty($gtm_id)) {
        $proxy_url = home_url('/metrics/gtm.js');
        ?>
        <!-- Carrothost Node-Free GTM Script -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;
        j.src='<?php echo esc_url($proxy_url); ?>?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','<?php echo esc_attr($gtm_id); ?>');</script>
        <!-- End Carrothost Node-Free GTM Script -->
        <?php
    }

    // Facebook Browser Pixel
    if (!empty($fb_pixel_id)) {
        ?>
        <!-- Carrothost Meta Browser Pixel -->
        <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '<?php echo esc_attr($fb_pixel_id); ?>');
        fbq('track', 'PageView');
        </script>
        <!-- End Meta Browser Pixel -->
        <?php
    }
}

// ৭. অ্যাক্টিভিটি লগ সংরক্ষণকারী হেল্পার
function chnf_log_event($event_name, $target, $status, $details = '-') {
    $logs = get_option('chnf_event_logs', []);
    if (!is_array($logs)) {
        $logs = [];
    }
    
    $logs[] = [
        'time'    => current_time('mysql'),
        'event'   => sanitize_text_field($event_name),
        'target'  => sanitize_text_field($target),
        'status'  => sanitize_text_field($status),
        'details' => is_array($details) ? wp_json_encode($details) : sanitize_text_field($details),
    ];

    if (count($logs) > 10) {
        $logs = array_slice($logs, -10);
    }

    update_option('chnf_event_logs', $logs);
}

// ৮. টেস্ট পিং এক্সিকিউটর
function chnf_run_diagnostics_ping() {
    $gtm_id = get_option('chnf_gtm_id');
    $fb_pixel_id = trim(get_option('chnf_fb_pixel_id'));
    $fb_token = trim(get_option('chnf_fb_access_token'));

    // GTM টেস্ট
    $test_gtm = !empty($gtm_id) ? $gtm_id : 'GTM-KK6466MJ';
    $gtm_url = home_url('/metrics/gtm.js?id=' . $test_gtm);
    $res = wp_remote_get($gtm_url, ['timeout' => 5]);
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
        chnf_log_event('Diagnostic Ping', 'Google Nginx Proxy', 'Success (200 OK)', 'Endpoint verified');
    }

    // Meta CAPI টেস্ট
    if (!empty($fb_pixel_id) && !empty($fb_token)) {
        chnf_send_meta_capi_event('Diagnostic_Test_Ping', ['status' => 'Manual Health Check']);
    }
}

// ৯. Facebook CAPI সেন্ডার
function chnf_send_meta_capi_event($event_name, $custom_data = []) {
    $pixel_id     = trim(get_option('chnf_fb_pixel_id'));
    $access_token = trim(get_option('chnf_fb_access_token'));
    $test_code    = trim(get_option('chnf_fb_test_code'));

    if (empty($pixel_id) || empty($access_token)) {
        return false;
    }

    $client_ip   = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
    $user_agent  = sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? 'Carrothost-SST-Agent');
    $current_url = home_url(add_query_arg(null, null));

    $event_payload = [
        'event_name'       => $event_name,
        'event_time'       => time(),
        'event_source_url' => $current_url,
        'action_source'    => 'website',
        'user_data'        => [
            'client_ip_address' => $client_ip,
            'client_user_agent' => $user_agent,
        ]
    ];

    if (!empty($custom_data)) {
        $event_payload['custom_data'] = $custom_data;
    }

    $body = ['data' => [$event_payload]];
    if (!empty($test_code)) {
        $body['test_event_code'] = $test_code;
    }

    $response = wp_remote_post("https://graph.facebook.com/v19.0/{$pixel_id}/events?access_token={$access_token}", [
        'headers'   => ['Content-Type' => 'application/json'],
        'body'      => wp_json_encode($body),
        'timeout'   => 5,
        'blocking'  => true,
        'sslverify' => true,
    ]);

    if (!is_wp_error($response)) {
        $code = wp_remote_retrieve_response_code($response);
        $res_body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200) {
            update_option('chnf_fb_last_status', 'success');
            $details = !empty($custom_data) ? (isset($custom_data['value']) ? 'Val: ' . $custom_data['value'] . ' ' . $custom_data['currency'] : 'Test Event Accepted') : 'URL: ' . $current_url;
            chnf_log_event($event_name, 'Facebook CAPI', 'Dispatched (200 OK)', $details);
            return true;
        } else {
            update_option('chnf_fb_last_status', 'error');
            $err_msg = isset($res_body['error']['message']) ? $res_body['error']['message'] : 'HTTP ' . $code;
            chnf_log_event($event_name, 'Facebook CAPI', 'Error (' . $code . ')', $err_msg);
            return false;
        }
    }

    return false;
}

// ১০. PageView ট্রিগার
add_action('wp_footer', 'chnf_trigger_pageview_event');
function chnf_trigger_pageview_event() {
    if (!is_admin()) {
        chnf_send_meta_capi_event('PageView');
    }
}

// ১১. WooCommerce Purchase ট্রিগার
add_action('woocommerce_thankyou', 'chnf_trigger_woocommerce_purchase', 10, 1);
function chnf_trigger_woocommerce_purchase($order_id) {
    if (!$order_id || !function_exists('wc_get_order')) {
        return;
    }
    
    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    $custom_data = [
        'currency' => $order->get_currency(),
        'value'    => (float) $order->get_total(),
        'order_id' => (string) $order_id,
    ];

    chnf_send_meta_capi_event('Purchase', $custom_data);
}