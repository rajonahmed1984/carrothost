=== Carrothost Server-Side Tracker ===
Contributors: apptimatic
Tags: tracking, gtm, facebook capi, sst, analytics
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.1.0
License: GPLv2 or later

Node-Free Server-Side Tracking for Google Tag Manager & Facebook CAPI powered by Carrothost Nginx Core.